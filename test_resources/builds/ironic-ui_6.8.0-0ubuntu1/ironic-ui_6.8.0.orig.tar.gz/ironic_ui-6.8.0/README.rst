=========
Ironic UI
=========

.. image:: https://governance.openstack.org/tc/badges/ironic-ui.svg

.. Change things from this point on

The Ironic UI is a Horizon plugin that will allow users to view and manage bare
metal nodes, ports and drivers.

* Free software: Apache license
* Documentation: https://docs.openstack.org/ironic-ui/latest
* Release notes: https://docs.openstack.org/releasenotes/ironic-ui/
* Source: https://opendev.org/openstack/ironic-ui
* Bugs: https://bugs.launchpad.net/ironic-ui

Features
--------

* View bare metal nodes
* View node details
* Apply maintenance and power on/off actions to the nodes
